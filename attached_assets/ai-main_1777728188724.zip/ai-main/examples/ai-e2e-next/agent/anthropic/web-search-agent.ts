import { anthropic } from '@ai-sdk/anthropic';
import { ToolLoopAgent, type InferAgentUIMessage } from 'ai';
export const anthropicWebSearchAgent = new ToolLoopAgent({
  model: anthropic('claude-sonnet-4-5'),
  tools: {
    webSearch: anthropic.tools.webSearch_20250305({
      maxUses: 3,
      userLocation: {
        type: 'approximate',
        city: 'New York',
        country: 'US',
        timezone: 'America/New_York',
      },
    }),
  },
  reasoning: 'medium',
});

export type AnthropicWebSearchMessage = InferAgentUIMessage<
  typeof anthropicWebSearchAgent
>;
