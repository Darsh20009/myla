import { xai } from '@ai-sdk/xai';
import { convertToModelMessages, streamText, type UIMessage } from 'ai';
export const maxDuration = 30;

export async function POST(req: Request) {
  const { messages }: { messages: UIMessage[] } = await req.json();

  const result = streamText({
    model: xai('grok-3'),
    messages: await convertToModelMessages(messages),
  });

  return result.toUIMessageStreamResponse();
}
